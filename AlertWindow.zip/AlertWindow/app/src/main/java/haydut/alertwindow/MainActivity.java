package haydut.alertwindow;
        import android.app.Activity;
        import android.app.ProgressDialog;
        import android.content.Context;
        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.os.AsyncTask;
        import android.os.Bundle;
        import android.os.Vibrator;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import org.jsoup.Jsoup;
        import org.jsoup.nodes.Document;
        import org.jsoup.nodes.Element;

public class MainActivity extends Activity {
    public static String SaveData = "SavedNodeMCUSetting";
    public static SharedPreferences settings;
    public static SharedPreferences.Editor editor;
    public static boolean NotifyStatus = true;
    private Button buttonFetchNodeMCU,buttonSave;
    private TextView TXTResultNodeMCU;
    private EditText ETXTNodeMcuLink , ETXTZamanlayici;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonFetchNodeMCU = (Button)findViewById(R.id.buttonFetchNodeMCU);
        buttonSave = (Button)findViewById(R.id.buttonSave);
        ETXTNodeMcuLink =(EditText)findViewById(R.id.editTextNodeMCULink);
        ETXTZamanlayici = (EditText)findViewById(R.id.editTextTimer);
        TXTResultNodeMCU = (TextView)findViewById(R.id.TXTResult);
        settings = getSharedPreferences(SaveData, MODE_PRIVATE);
        editor = settings.edit();
        if(NotifyStatus){
            NotifyStatus = false;
        }
        if (MainActivity.settings.getString("Link", "").length()>0){
            ETXTNodeMcuLink.setText(MainActivity.settings.getString("Link", ""));
            ETXTZamanlayici.setText(MainActivity.settings.getString("Time", ""));
        }

        buttonFetchNodeMCU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    new FetchNoMcu().execute();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ETXTZamanlayici.getText().length()>0 & ETXTNodeMcuLink.getText().length()>0){
                    editor.putString("Link", ETXTNodeMcuLink.getText().toString());
                    editor.putString("Time", ETXTZamanlayici.getText().toString());
                    editor.commit();
                    stopService(new Intent(MainActivity.this, CheckWindowStatus.class));
                    startService(new Intent(MainActivity.this, CheckWindowStatus.class));
                    NotifyStatus = true;
                }else{
                    Toast.makeText(MainActivity.this, "Lütfen Boş Bırakmayınız!",
                            Toast.LENGTH_LONG).show();
                }


            }
        });
        TXTResultNodeMCU.setText(CheckWindowStatus.authors);
    }
    private class FetchNoMcu extends AsyncTask<Void, Void, Void> {

        String authors = "Null";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setTitle("NodeMCU");
            progressDialog.setMessage("Veri Çekiliyor...");
            progressDialog.setIndeterminate(false);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try{
                Document doc  = Jsoup.connect(MainActivity.settings.getString("Link", "")).get();
                Element elements = doc.select("p").first();
                authors = elements.text();
            }catch (Exception e){
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Log.v("Sonuc",authors);
            TXTResultNodeMCU.setText(authors);
            if (authors.toString().equals("acik")){
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(400);
                Log.v("Sonuc",authors+" titredi");

            }
            progressDialog.dismiss();
        }
    }



}
