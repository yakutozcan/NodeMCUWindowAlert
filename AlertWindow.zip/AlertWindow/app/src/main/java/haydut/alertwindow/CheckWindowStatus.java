package haydut.alertwindow;

/**
 * Created by haydut on 01.10.2016.
 */
        import java.util.Timer;
        import java.util.TimerTask;
        import android.app.Notification;
        import android.app.NotificationManager;
        import android.app.PendingIntent;
        import android.app.Service;
        import android.content.Context;
        import android.content.Intent;
        import android.media.MediaPlayer;
        import android.net.ConnectivityManager;
        import android.net.NetworkInfo;
        import android.os.AsyncTask;
        import android.os.Handler;
        import android.os.IBinder;
        import android.os.Looper;
        import android.os.Vibrator;
        import android.util.Log;
        import org.jsoup.Jsoup;
        import org.jsoup.nodes.Document;
        import org.jsoup.nodes.Element;

        import static haydut.alertwindow.MainActivity.NotifyStatus;

public class CheckWindowStatus extends Service
{
    private static final int MY_NOTIFICATION_ID=1;

    Timer zamanlayici;
    Handler yardimci;
    int i=1;
    public static String authors = "null";
    @Override
    public IBinder onBind(Intent intent)
    {
        return null;
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        zamanlayici = new Timer();
        yardimci = new Handler(Looper.getMainLooper());
        zamanlayici.scheduleAtFixedRate(new TimerTask()
        {
            @Override
            public void run()
            {
                try {
                    if(NotifyStatus) {
                        FetchNodeMcu();
                        Log.v("Zaman",Integer.parseInt(MainActivity.settings.getString("Time", ""))+"");
                    }
                }catch (Exception e){
                    e.printStackTrace();

                }
            }
        }, 0, Integer.parseInt(MainActivity.settings.getString("Time", "")));
    }

    private void FetchNodeMcu()
    {
        yardimci.post(new Runnable()
        {
            @Override
            public void run()
            {
            new FetchNoMcu().execute();
            }
        });
    }

    @Override
    public void onDestroy()
    {
        zamanlayici.cancel();
        super.onDestroy();
    }
    private class FetchNoMcu extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            if(isOnline()){
                try{
                    authors = null;
                    Document doc  = Jsoup.connect(MainActivity.settings.getString("Link", "")).get();
                    Element elements = doc.select("p").first();
                    authors = elements.text();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }else{
                Log.v("Sonuc","Yok internet");
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            try {
                if (authors.toString().equals("acik")){
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(400);
                    String value = MainActivity.settings.getString("Link", "");
                    String values = MainActivity.settings.getString("Time", "");

                    Log.v("Sonuc",authors+"VALUE::"+value+"Time:"+values+":: titredi Servisden"+ i++);
                    if(NotifyStatus) {
                        showNotification();
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            Log.v("Sonuc",">>>"+authors);
            //progressDialog.dismiss();
        }

    }
    public void showNotification() {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0);
        Notification notification = new android.support.v7.app.NotificationCompat.Builder(this)
                .setTicker("Pencereden Bildirim var!")
                .setSmallIcon(R.drawable.window)
                .setContentTitle("Pencereden Bildirim var!")
                .setContentText("Detay: "+authors)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(MY_NOTIFICATION_ID, notification);
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.sound);
        mp.start();
    }
    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
}
